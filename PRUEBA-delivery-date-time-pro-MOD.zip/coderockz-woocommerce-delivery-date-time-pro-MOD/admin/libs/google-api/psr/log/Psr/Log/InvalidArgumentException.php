<?php

namespace WooDelivery\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
