<?php
namespace WooDelivery\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException {}
