<?php
namespace WooDelivery\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException {}
